package com.hashtag.hashtaggenrator.hashtagforinstagram.freehashtag.hasham.Retrofit;

public class JSONResponse {

    private BioModel[] records;

    public BioModel[] getrecords() {
        return records;
    }
}
